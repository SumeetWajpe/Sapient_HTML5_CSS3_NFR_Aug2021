// Define the webcomponent
class Helloworld extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }
}

customElements.define("uc-helloworld", Helloworld);
