class Tooltip extends HTMLElement {
  tooltip = null;
  tooltipText = "Some Dummy Tooltip";
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    if (this.hasAttribute("text")) {
      this.tooltipText = this.getAttribute("text");
    }

    const tooltipIcon = document.createElement("span");
    tooltipIcon.innerText = "(?)";
    tooltipIcon.addEventListener("mouseenter", this.showTooltip.bind(this));
    tooltipIcon.addEventListener("mouseleave", this.hideTooltip.bind(this));

    this.style.position = "relative";
    this.style.cursor = "pointer";

    this.shadowRoot.appendChild(tooltipIcon);
  }

  showTooltip() {
    this.tooltip = document.createElement("div");
    this.tooltip.innerText = this.tooltipText;
    this.tooltip.style.width = "100px";
    this.tooltip.style.height = "8px";
    this.tooltip.style.border = "2px solid grey";
    this.tooltip.style.borderRadius = "5px";
    this.tooltip.style.padding = "2px";

    this.tooltip.style.position = "absolute";
    this.tooltip.style.top = "-10";
    this.tooltip.style.left = "0";

    this.tooltip.style.zIndex = "5";
    this.tooltip.style.background = "black";
    this.tooltip.style.color = "white";
    this.tooltip.style.fontFamily = "Verdana";
    this.tooltip.style.fontSize = "6px";
    this.shadowRoot.appendChild(this.tooltip);
  }

  hideTooltip() {
    this.shadowRoot.removeChild(this.tooltip);
  }
}

customElements.define("uc-tooltip", Tooltip);

{
  /* <uc-tooltip text="Tooltip here !"></uc-tooltip>; */
}
