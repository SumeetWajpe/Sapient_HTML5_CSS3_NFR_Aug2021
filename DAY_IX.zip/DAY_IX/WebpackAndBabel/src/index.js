class Point {
  x = 10;
  y = 10;
}

let Add = (x, y) => x + y;
