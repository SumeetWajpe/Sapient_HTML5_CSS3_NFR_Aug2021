function GetAllPosts() {
  return fetch("https://jsonplaceholder.typicode.com/posts").then(
    (response) => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error("Resource Not Found !");
      }
    }
  );
}
