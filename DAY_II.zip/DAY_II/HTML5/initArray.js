// restrictions on workers
//1. Can access window | document object
//2. Can use XMLHttpRequest -> AJAX request
//3. Can use any Javascript object (String,Array,Math)
//4. Can't access global variable
var largeArray = [];
onmessage = function (dataFromMainThread) {
  console.log(dataFromMainThread.data);
  //   console.log(this); // DedicatedWorkerGlobalScope
  for (var i = 0; i < 8000; i++) {
    largeArray[i] = [];
    for (var j = 0; j < 8000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[2000][2000]);
  // largeArray = null -> to freeup the memory
};
