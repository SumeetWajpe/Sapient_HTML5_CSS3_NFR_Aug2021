function GetAllPosts() {
  return axios.get("https://jsonplaceholder.typicode.com/posts");
}
