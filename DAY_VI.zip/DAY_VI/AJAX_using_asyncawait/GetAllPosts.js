function GetAllPosts() {
  return new Promise(function (resolve, reject) {
    let xmlHttpReq = new XMLHttpRequest();
    xmlHttpReq.onreadystatechange = function () {
      // console.log("Ready State : " + xmlHttpReq.readyState);

      if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
        resolve(xmlHttpReq.responseText);
      } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
        reject(xmlHttpReq.status);
      }
    };

    xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlHttpReq.send(); // async
  });
}
