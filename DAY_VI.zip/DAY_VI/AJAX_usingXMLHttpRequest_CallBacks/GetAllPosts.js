// onreadystatechange => event => register a callback
// readyState => status of request
function GetAllPosts(callback) {
  // AJAX request !
  // new XMLHttpRequest()
  // open()  => Initiate the handshake / request / connection
  // send() => Make the actual async call

  console.log("GetAllPosts called !");
  let xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.onreadystatechange = function () {
    // console.log("Ready State : " + xmlHttpReq.readyState);

    if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
      callback(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
      callback(xmlHttpReq.status, null);
    }
  };

  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/postss");
  xmlHttpReq.send(); // async
  console.log("Request Made !");
}
